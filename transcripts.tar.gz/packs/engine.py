import json,os,sys,urllib.request as W
U0=os.environ["MAKEFUN_ENV_URL"]
MATE=30000;INF=33000;BUDGET=150000
# sunfish PST (compact)
P={"P":(0,0,0,0,0,0,0,0,78,83,86,73,102,82,85,90,7,29,21,44,40,31,44,7,-17,16,-2,15,14,0,15,-13,-26,3,10,9,6,1,0,-23,-22,9,5,-11,-10,-2,3,-19,-31,8,-7,-37,-36,-14,3,-31,0,0,0,0,0,0,0,0),"N":(-66,-53,-75,-75,-10,-55,-58,-70,-3,-6,100,-36,4,62,-4,-14,10,67,1,74,73,27,62,-2,24,24,45,37,33,41,25,17,-1,5,31,21,22,35,2,0,-18,10,13,22,18,15,11,-14,-23,-15,2,0,2,0,-23,-20,-74,-23,-26,-24,-19,-35,-22,-69),"B":(-59,-78,-82,-76,-23,-107,-37,-50,-11,20,35,-42,-39,31,2,-22,-9,39,-32,41,52,-10,28,-14,25,17,20,34,26,25,15,10,13,10,17,23,17,16,0,7,14,25,24,15,8,25,20,15,19,20,11,6,7,6,20,16,-7,2,-15,-12,-14,-15,-10,-10),"R":(35,29,33,4,37,33,56,50,55,29,56,67,55,62,34,60,19,35,28,33,45,27,25,15,0,5,16,13,18,-4,-9,-6,-28,-35,-16,-21,-13,-29,-46,-30,-42,-28,-42,-25,-25,-35,-26,-46,-53,-38,-31,-26,-29,-43,-44,-53,-30,-24,-18,5,-2,-18,-31,-32),"Q":(6,1,-8,-104,69,24,88,26,14,32,60,-10,20,76,57,24,-2,43,32,60,72,63,43,2,1,-16,22,17,25,20,-13,-6,-14,-15,-2,-5,-1,-10,-20,-22,-30,-6,-13,-11,-16,-11,-16,-27,-36,-18,0,-19,-15,-15,-21,-38,-39,-30,-31,-13,-31,-36,-34,-42),"K":(4,54,47,-99,-99,60,83,-62,-32,10,55,56,56,55,10,3,-62,12,-57,44,-67,28,37,-31,-55,50,11,-4,-19,13,0,-49,-55,-43,-52,-28,-51,-47,-8,-50,-47,-42,-43,-79,-64,-32,-29,-32,-4,3,-14,-50,-57,-18,13,4,17,30,-3,-14,6,-1,40,18)}
C128=[(i>>3)*16+(i&7) for i in range(64)]
C64=[(s>>4)*8+(s&7) for s in range(128)]
_rnd=0x9E3779B97F4A7C15
def _n():
    global _rnd
    _rnd^=(_rnd<<13)&0xFFFFFFFFFFFFFFFF;_rnd^=_rnd>>7;_rnd^=(_rnd<<17)&0xFFFFFFFFFFFFFFFF
    return _rnd&0xFFFFFFFFFFFFFFFF
ZP=[_n() for _ in range(2048)];ZS=_n();ZC=[_n() for _ in range(16)];ZE=[_n() for _ in range(8)]
ND=(-33,-31,-18,-14,14,18,31,33);KD=(-17,-16,-15,-1,1,15,16,17);BD=(-17,-15,15,17);RD=(-16,-1,1,16)
KP=[15]*128;KP[0]=13;KP[7]=14;KP[4]=12;KP[112]=7;KP[119]=11;KP[116]=3
B=[0]*128;SIDE=0;CAST=0;EP=-1;H=0;M=0
OCC=[0,0];PWN=[0,0];KING=[4,116];U=[];TT={};KL=[(0,0)]*128;HIST={};NODES=0;LMT=0;AB=[0]
PV=[0,100,325,335,500,975,0]
PT=[0]*2048
for t,ch in enumerate("PNBRQK"):
    for s in range(128):
        if s&0x88: continue
        r,f=s>>4,s&7
        PT[(t+1)*128+s]=PV[t+1]+P[ch][(7-r)*8+f]
        PT[(t+9)*128+s]=-(PV[t+1]+P[ch][r*8+f])
PV=[0,100,325,335,500,975,0]
def atk(sq,by):
    b=B
    if by:
        t=sq+15
        if not t&0x88 and b[t]==9: return 1
        t=sq+17
        if not t&0x88 and b[t]==9: return 1
    else:
        t=sq-15
        if not t&0x88 and b[t]==1: return 1
        t=sq-17
        if not t&0x88 and b[t]==1: return 1
    n=2+by*8
    for d in ND:
        t=sq+d
        if not t&0x88 and b[t]==n: return 1
    k=6+by*8
    for d in KD:
        t=sq+d
        if not t&0x88 and b[t]==k: return 1
    r=4+by*8;q=5+by*8;bi=3+by*8
    for d in RD:
        t=sq+d
        while not t&0x88:
            p=b[t]
            if p:
                if p==r or p==q: return 1
                break
            t+=d
    for d in BD:
        t=sq+d
        while not t&0x88:
            p=b[t]
            if p:
                if p==bi or p==q: return 1
                break
            t+=d
    return 0
def load(fen):
    global B,SIDE,CAST,EP,H,M,OCC,PWN,KING
    B=[0]*128
    ps=fen.split();rows=ps[0].split("/")
    for ri,row in enumerate(rows):
        f=0
        for ch in row:
            if ch.isdigit(): f+=int(ch)
            else:
                B[(7-ri)*16+f]=" pnbrqk".index(ch.lower())+(0 if ch.isupper() else 8);f+=1
    SIDE=0 if ps[1]=="w" else 1
    CAST=0
    if "K" in ps[2]: CAST|=1
    if "Q" in ps[2]: CAST|=2
    if "k" in ps[2]: CAST|=4
    if "q" in ps[2]: CAST|=8
    EP=-1
    if ps[3]!="-": EP=(int(ps[3][1])-1)*16+ord(ps[3][0])-97
    OCC=[0,0];PWN=[0,0];KING=[-1,-1];M=0;H=0
    for sq in range(128):
        pc=B[sq]
        if not pc or sq&0x88: continue
        c=pc>>3;i=C64[sq]
        OCC[c]|=1<<i
        if pc&7==1: PWN[c]|=1<<i
        if pc&7==6: KING[c]=sq
        M+=PT[pc*128+sq];H^=ZP[pc*128+sq]
    if SIDE: H^=ZS
    H^=ZC[CAST]
    if EP>=0: H^=ZE[EP&7]
def gen(caps):
    o=[];ap=o.append;b=B;us=SIDE;th=us^1;ep=EP;bb=OCC[us]
    fwd=16 if not us else -16;pro=6 if not us else 1
    while bb:
        lo=bb&-bb;bb^=lo;f=C128[lo.bit_length()-1];pc=b[f];t=pc&7
        if t==1:
            r=f>>4;one=f+fwd
            if not b[one]:
                if r==pro:
                    for pr in (5,4,3,2): ap(f|one<<7|pr<<14)
                elif not caps:
                    ap(f|one<<7)
                    if r==(1 if not us else 6) and not b[one+fwd]: ap(f|(one+fwd)<<7|8<<17)
            for d in (fwd-1,fwd+1):
                to=f+d
                if to&0x88: continue
                q=b[to]
                if q and q>>3==th:
                    if r==pro:
                        for pr in (5,4,3,2): ap(f|to<<7|pr<<14|1<<17)
                    else: ap(f|to<<7|1<<17)
                elif to==ep: ap(f|to<<7|1<<17|2<<17)
            continue
        if t==2:
            for d in ND:
                to=f+d
                if to&0x88: continue
                q=b[to]
                if not q:
                    if not caps: ap(f|to<<7)
                elif q>>3==th: ap(f|to<<7|1<<17)
            continue
        if t==6:
            for d in KD:
                to=f+d
                if to&0x88: continue
                q=b[to]
                if not q:
                    if not caps: ap(f|to<<7)
                elif q>>3==th: ap(f|to<<7|1<<17)
            if not caps and not atk(f,th):
                base=0 if not us else 112;c1=1 if not us else 4;c2=2 if not us else 8
                if CAST&c1 and not b[base+5] and not b[base+6] and not atk(base+5,th) and not atk(base+6,th): ap(f|(base+6)<<7|4<<17)
                if CAST&c2 and not b[base+1] and not b[base+2] and not b[base+3] and not atk(base+3,th) and not atk(base+2,th): ap(f|(base+2)<<7|4<<17)
            continue
        dirs=BD if t==3 else RD if t==4 else KD
        for d in dirs:
            to=f+d
            while not to&0x88:
                q=b[to]
                if not q:
                    if not caps: ap(f|to<<7)
                else:
                    if q>>3==th: ap(f|to<<7|1<<17)
                    break
                to+=d
    return o
def mk(m,inchk):
    global SIDE,CAST,EP,H,M,OCC,PWN,KING
    f=m&127;to=(m>>7)&127;pr=(m>>14)&7;fl=(m>>17)&15
    pc=B[f];us=pc>>3;th=us^1
    csq=to
    if fl&2: csq=to-16 if not us else to+16
    cap=B[csq]
    U.append((m,pc,cap,CAST,EP,H,M,OCC[0],OCC[1],PWN[0],PWN[1],KING[0],KING[1]))
    mg=M;occ=OCC;pwn=PWN
    if cap:
        B[csq]=0;ci=C64[csq];occ[th]^=1<<ci
        if cap&7==1: pwn[th]^=1<<ci
        mg-=PT[cap*128+csq];H^=ZP[cap*128+csq]
    B[f]=0;fi=C64[f];occ[us]^=1<<fi
    if pc&7==1: pwn[us]^=1<<fi
    mg-=PT[pc*128+f];H^=ZP[pc*128+f]
    pl=pc if not pr else pr|us<<3
    B[to]=pl;ti=C64[to];occ[us]^=1<<ti
    if pl&7==1: pwn[us]^=1<<ti
    mg+=PT[pl*128+to];H^=ZP[pl*128+to]
    if pc&7==6: KING[us]=to
    if fl&4:
        rf=f+3 if to>f else f-4;rt=f+1 if to>f else f-1
        rp=B[rf];B[rf]=0;B[rt]=rp
        occ[us]^=1<<C64[rf];occ[us]^=1<<C64[rt]
        mg+=PT[rp*128+rt]-PT[rp*128+rf];H^=ZP[rp*128+rf]^ZP[rp*128+rt]
    H^=ZC[CAST];CAST&=KP[f]&KP[to];H^=ZC[CAST]
    if EP>=0: H^=ZE[EP&7]
    EP=-1
    if fl&8:
        e=(f+to)>>1
        if pwn[th]&((1<<C64[to-1])|(1<<C64[to+1])):
            EP=e;H^=ZE[e&7]
    SIDE=th;M=mg;OCC=occ;PWN=pwn;H=H^ZS
    k=KING[us]
    if pc&7==6 or fl&4 or fl&2 or inchk or k>>4==f>>4 or (k&7)==(f&7) or (k-f)%15==0 or (k-f)%17==0:
        if atk(k,th): um();return 0
    return 1
def um():
    global SIDE,CAST,EP,H,M,OCC,PWN,KING
    m,pc,cap,cast,ep,h,mg,o0,o1,p0,p1,k0,k1=U.pop()
    f=m&127;to=(m>>7)&127;fl=(m>>17)&15;us=pc>>3
    B[f]=pc;B[to]=0
    if fl&2: B[to-16 if not us else to+16]=cap
    elif cap: B[to]=cap
    if fl&4:
        rf=f+3 if to>f else f-4;rt=f+1 if to>f else f-1
        B[rf]=B[rt];B[rt]=0
    SIDE=us;CAST=cast;EP=ep;H=h;M=mg;OCC=[o0,o1];PWN=[p0,p1];KING=[k0,k1]
def nmk():
    global SIDE,H,EP
    U.append((SIDE,H,EP));H^=ZS
    if EP>=0: H^=ZE[EP&7];EP=-1
    SIDE^=1
def num():
    global SIDE,H,EP
    SIDE,H,EP=U.pop()
def ev():
    return M if not SIDE else -M
def qs(a,b,ply):
    global NODES
    NODES+=1
    if NODES>LMT: AB[0]=1;return 0
    st=ev()
    if st>=b: return st
    if st>a: a=st
    sc=[]
    for m in gen(1):
        to=(m>>7)&127
        sc.append((PV[B[to]&7] if B[to] else 0,m))
    sc.sort(reverse=True)
    ck=atk(KING[SIDE],SIDE^1)
    for _,m in sc:
        if mk(m,ck):
            v=-qs(-b,-a,ply+1);um()
            if AB[0]: return 0
            if v>=b: return v
            if v>a: a=v
    return a
def order(ms,ply,hb):
    sc=[];k1,k2=KL[ply];b=B
    for m in ms:
        to=(m>>7)&127
        if m==hb: v=1<<28
        elif m&(1<<17): v=1<<20
        elif m==k1: v=1<<19
        elif m==k2: v=(1<<19)-1
        elif (m>>14)&7: v=1<<18
        else: v=HIST.get(m,0)
        sc.append((v,m))
    sc.sort(reverse=True)
    return sc
def ab(d,a,b,ply):
    global NODES
    NODES+=1
    if NODES>LMT: AB[0]=1;return 0
    chk=atk(KING[SIDE],SIDE^1)
    if chk: d+=1
    if d<=0: return qs(a,b,ply)
    key=H;ent=TT.get(key);hb=0
    if ent:
        hb=ent[2]
        if ent[0]>=d:
            v=ent[1]
            if v>MATE-200: v-=ply
            elif v<-MATE+200: v+=ply
            f=ent[3]
            if f==0 or f==1 and v<=a or f==2 and v>=b: return v
    if d>=3 and not chk:
        nmk()
        v=-ab(d-3,-b,-b+1,ply+1)
        num()
        if AB[0]: return 0
        if v>=b: return v
    ms=gen(0)
    best=-INF;flag=1;bm=0;mc=0;legal=0
    for _,m in order(ms,ply,hb):
        mc+=1
        q=not m&(1<<17) and not (m>>14)&7
        r=1 if (q and mc>3 and d>=3 and not chk) else 0
        if mk(m,chk):
            legal+=1
            v=-ab(d-1-r,-a-1,-a,ply+1)
            if not AB[0] and v>a and (r or v<b):
                v=-ab(d-1,-b,-a,ply+1)
            um()
            if AB[0]: return 0
            if v>best: best=v;bm=m
            if v>a: a=v;flag=0
            if v>=b:
                if q: KL[ply]=(m,KL[ply][0]);HIST[m]=HIST.get(m,0)+d*d
                flag=2;break
    if not legal: return MATE-ply if chk else 0
    if MATE-200<best<=MATE: best+=ply
    elif -MATE<=best<-MATE+200: best-=ply
    TT[key]=(d,best,bm,flag)
    return best
def cvt(m):
    f=m&127;to=(m>>7)&127;pr=(m>>14)&7
    s="abcdefgh"[f&7]+str((f>>4)+1)+"abcdefgh"[to&7]+str((to>>4)+1)
    return s+"  nbrq"[pr] if pr else s
def mv(fen,budget=BUDGET,depth=0):
    global NODES,LMT,TT,KL,U,HIST,AB
    load(fen);TT={};KL=[(0,0)]*128;U=[];HIST={};AB[0]=0
    ms=gen(0)
    if not ms: return None
    best=ms[0];NODES=0;LMT=budget or 1<<30
    for d in range(1,40):
        cur=best;bs=-INF;done=1;ck=atk(KING[SIDE],SIDE^1)
        for _,m in order(ms,0,best):
            if mk(m,ck):
                v=-ab(d-1,-INF,-bs,1);um()
                if AB[0]: done=0;break
                if v>bs: bs=v;cur=m
        if not done: break
        best=cur
        if bs>MATE-200: break
        if depth and d>=depth: break
    return cvt(best)
def post(p,b):
    with W.urlopen(W.Request(U0+p,json.dumps(b).encode(),{"content-type":"application/json"}),timeout=60) as x:
        return json.load(x)
def run():
    while 1:
        g=post("/game",{})
        if g["status"]=="done": break
        while g["status"]=="your_move":
            m=mv(g["fen"])
            if m is None or m not in g["legal_moves"]:
                m=g["legal_moves"][0]
            g=post("/move",{"game":g["game"],"move":m})
if __name__=="__main__":
    run()
